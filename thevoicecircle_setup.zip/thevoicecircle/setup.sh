#!/bin/bash
echo "Setting up TheVoiceCircle project..."
python3 setup.py
read -p "Press Enter to continue..."
